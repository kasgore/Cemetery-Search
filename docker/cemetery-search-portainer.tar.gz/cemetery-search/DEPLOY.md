# Deploying on the Raspberry Pi (Portainer)

Everything needed is in this directory — app, full dataset (38 cemeteries,
649 requests, both burial registers), Dockerfile, and compose file. The base
image (`python:3.12-slim`) has native ARM builds, so the Pi builds it itself
in a minute or two.

## Install (one SSH session)

```bash
# 1. copy the tarball to the Pi (from your computer):
scp cemetery-search-portainer.tar.gz pi@<pi-address>:~

# 2. on the Pi:
ssh pi@<pi-address>
mkdir -p ~/stacks && tar -xzf cemetery-search-portainer.tar.gz -C ~/stacks
cd ~/stacks/cemetery-search
docker compose up -d --build      # (sudo if your user isn't in the docker group)
```

Open `http://<pi-address>:8420/` — done. The container serves the baked
dataset instantly and then keeps everything refreshed by itself (requests
every 6 h, memorial indexes weekly, cemetery discovery daily, registers
every ~60 days). Progress: `docker logs -f cemetery-search` or
`http://<pi-address>:8420/api/status`.

The container now appears in **Portainer** (Containers, and under Stacks as
an external stack) where you can restart it, view logs, and edit env vars.

## Updating later

Extract a newer tarball over the same directory and rerun
`docker compose up -d --build`. The `/data` volume keeps all refreshed data
and cache — nothing is re-downloaded.

## ⚠ Phone GPS needs HTTPS

Over plain `http://pi:8420` the app works as a search/lookup tool, but
browsers block GPS, compass, and offline install on insecure pages. To get
the full field experience, put it behind HTTPS and open that address on the
phone, then *Add to Home Screen*. Easy options:

- **Tailscale** on the Pi + phone, with `tailscale serve` (gives you a valid
  HTTPS URL, works from the cemetery over cellular too — recommended);
- a reverse proxy with a Let's Encrypt cert (Nginx Proxy Manager runs fine
  in Portainer on the Pi) + a DDNS hostname;
- or push the repo to GitHub — the Pages copy is already HTTPS (data updates
  only when you commit a regenerated cemetery-data.js, though).

## Knobs

Env vars in `docker-compose.yml`: `REFRESH_HOURS` (default 6),
`RADIUS_MILES` (default 15 — raise it and the next discovery cycle pulls in
farther cemeteries automatically), `PORT`, `AUTO_REFRESH=0` to disable
self-updating. Deeper settings (counties scanned, pinned cemeteries, BS&A
registers): `server/refresher.py` DEFAULT_CONFIG or a `server/config.json`
override.
