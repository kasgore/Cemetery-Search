# Deploying Cemetery Search — http://192.168.5.14/ and https://192.168.5.14/

Everything is served by one Python script (`app.py`): the app on ports
**80 (http)** and **443 (https, self-signed)**, the API, and the automatic
data refresher. This directory is self-contained — app, full dataset
(38 cemeteries, 649 requests, both burial registers), and Docker files.

## Raspberry Pi / Portainer

```bash
# 1. copy the tarball to the Pi (from your computer):
scp cemetery-search-portainer.tar.gz pi@<pi-address>:~

# 2. on the Pi:
ssh pi@<pi-address>
mkdir -p ~/stacks && tar -xzf cemetery-search-portainer.tar.gz -C ~/stacks
cd ~/stacks/cemetery-search
docker compose up -d --build      # (sudo if your user isn't in the docker group)
```

**Which 192.168.5.14 setup do you have?** (see the comments in
`docker-compose.yml`):

- **A — the Pi itself is 192.168.5.14**: deploy as-is. Ports 80/443 are
  mapped to the host. (If another container already uses 80/443 on the Pi,
  that container and this one will conflict — change one of them.)
- **B — the container gets its own dedicated IP 192.168.5.14** (macvlan in
  Portainer): delete the `ports:` block, uncomment the `networks:` blocks and the
  PORT/HTTPS_PORT env overrides (the app must listen on 80/443 itself under
  macvlan), and set `parent:` to the Pi's LAN interface
  (usually `eth0`). Note the
  macvlan quirk: the Pi host itself can't browse to the container's IP;
  every other device on the network can.

Then open **http://192.168.5.14/** — or **https://192.168.5.14/** for the
full field experience (below). The container appears in **Portainer** for
restarts, logs, and env edits. Progress: `docker logs -f cemetery-search`
or `/api/status`.

## About https://192.168.5.14/ (self-signed)

The server generates its own certificate for 192.168.5.14 on first boot
(kept in the /data volume). Browsers can't verify a self-signed cert for a
private IP, so **the first visit shows a warning — tap Advanced → Proceed
(once per device)**. After that:

- ✅ GPS, compass, and the Guide arrow work on the phone (secure context)
- ⚠ offline/home-screen *install* (service worker) still requires a
  publicly-trusted cert — if you ever want that, run **Tailscale** on the
  Pi + phone with `tailscale serve` (valid HTTPS URL, also reachable from
  the cemetery over cellular), or a reverse proxy with Let's Encrypt.

For everyday use: browse to https://192.168.5.14/ at home on Wi-Fi; in the
field you'd need the Tailscale option anyway (the Pi isn't reachable from
the cemetery otherwise).

## Running it directly (no Docker — e.g. on your PC)

```bash
pip install -r requirements.txt
python app.py
```

Same server at http://localhost:8420/ (set `HTTPS_PORT=8443` for a local
https listener too). Refreshed data lands in `./data/` and an updated
`cemetery-data.js` next to the script.

## Updating later

Extract a newer tarball over the same directory and rerun
`docker compose up -d --build`. The `/data` volume keeps all refreshed data,
caches, and the generated certificate — nothing is re-downloaded.

## Knobs

Env vars in `docker-compose.yml`: `REFRESH_HOURS` (default 6),
`RADIUS_MILES` (default 15 — raise it and the next discovery cycle pulls in
farther cemeteries automatically), `CERT_HOSTS` (SANs for the self-signed
cert), `PORT` / `HTTPS_PORT`, `AUTO_REFRESH=0` to disable self-updating.
Deeper settings (counties scanned, pinned cemeteries, BS&A registers):
`refresher.py` DEFAULT_CONFIG or a `config.json` file next to it.

## Aerial imagery

The map shows USGS NAIP aerial photography (public domain, ~0.6 m/pixel —
headstone rows are visible) under the plot dots for every cemetery. The
server pre-caches tiles for all 38 cemeteries into the /data volume on its
first refresh cycle (~10 min, ~150-250 MB) and fills in anything else on
demand while online, so the aerial map works offline afterward. The 🛰
button on the Map tab toggles the layer.
