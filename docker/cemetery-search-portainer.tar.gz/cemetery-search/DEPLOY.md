# Deploying Cemetery Search

Everything is served by one Python script (`app.py`): the app, the API, and
the automatic data refresher. This directory is self-contained — app, full
dataset (38 cemeteries, 649 requests, both burial registers), and Docker
files.

## Raspberry Pi / Portainer

```bash
# 1. copy the tarball to the Pi (from your computer):
scp cemetery-search-portainer.tar.gz pi@<pi-address>:~

# 2. on the Pi:
ssh pi@<pi-address>
mkdir -p ~/stacks && tar -xzf cemetery-search-portainer.tar.gz -C ~/stacks
cd ~/stacks/cemetery-search
docker compose up -d --build      # (sudo if your user isn't in the docker group)
```

Open `http://<pi-address>:8420/`. The base image (`python:3.12-slim`) has
native ARM builds, so the Pi builds it in a minute or two. The container then
appears in **Portainer** (Containers, and under Stacks as an external stack)
for restarts, logs, and env edits. Progress:
`docker logs -f cemetery-search` or `http://<pi-address>:8420/api/status`.

## Running it directly (no Docker — e.g. on your PC)

```bash
pip install -r requirements.txt
python app.py
```

Same server, same auto-refresh, at http://localhost:8420/. Refreshed data
lands in `./data/` and an updated `cemetery-data.js` next to the script.

## Updating later

Extract a newer tarball over the same directory and rerun
`docker compose up -d --build`. The `/data` volume keeps all refreshed data
and caches — nothing is re-downloaded.

## ⚠ Phone GPS needs HTTPS

Over plain `http://pi:8420` the app works as a search/lookup tool, but
browsers block GPS, compass, and offline install on insecure pages. To get
the full field experience, put it behind HTTPS and open that address on the
phone, then *Add to Home Screen*. Easy options:

- **Tailscale** on the Pi + phone, with `tailscale serve` (valid HTTPS URL,
  reachable from the cemetery over cellular — recommended);
- a reverse proxy with a Let's Encrypt cert + DDNS hostname (Nginx Proxy
  Manager runs fine in Portainer on the Pi).

## Knobs

Env vars in `docker-compose.yml`: `REFRESH_HOURS` (default 6),
`RADIUS_MILES` (default 15 — raise it and the next discovery cycle pulls in
farther cemeteries automatically), `PORT`, `AUTO_REFRESH=0` to disable
self-updating. Deeper settings (counties scanned, pinned cemeteries, BS&A
registers): `refresher.py` DEFAULT_CONFIG or a `config.json` file next to it.
